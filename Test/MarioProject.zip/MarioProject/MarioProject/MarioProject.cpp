#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include<SDL_mixer.h>
#include "constant.h"
using namespace std;




int main(int argc, char* args[])
{
	//Globals
	SDL_Window* g_window = nullptr;

	//Function Prototypes
	bool InitSDL();
	void CloseSDL();


		if (SDL_Init(SDL_INIT_VIDEO) < 0)
		{
			cout << "SDL did not initalise. Error" << SDL_GetError() << endl;
			return false;
		}

		else
		{
			g_window = SDL_CreateWindow("Games Engine Creation",
				SDL_WINDOWPOS_UNDEFINED,
				SDL_WINDOWPOS_UNDEFINED,
				SCREEN_WIDTH,
				SCREEN_HEIGHT,
				SDL_WINDOW_SHOWN);

			if (g_window == nullptr)
			{
				// window failed 
				cout << "Window was not created. Error: " << SDL_GetError();
				return false;
			}

			else
			{
				SDL_UpdateWindowSurface;
				SDL_Delay(2000);
			}
		}

		


}








